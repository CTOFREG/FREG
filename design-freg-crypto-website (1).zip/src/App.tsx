import { useEffect, useMemo, useRef, useState } from 'react';

const CA = '9LbueXn3HMWWSTZPbH8jJKEZNKnb6YvTVn8HvqeQpump';
const images = {
  logo: '/images/freg.png',
  capsule: '/images/freg-logo.png',
  hand: '/images/freg-hand.png',
  rocket: '/images/freg-rocket.png',
  power: '/images/freg-power.png',
};

const links = {
  jupiter: `https://jup.ag/swap/SOL-${CA}`,
  pump: `https://pump.fun/coin/${CA}`,
  dex: `https://dexscreener.com/solana/${CA}`,
  birdeye: `https://birdeye.so/token/${CA}?chain=solana`,
  twitter: 'https://x.com/i/communities/2026761284721717328',
  telegram: 'https://t.me/FregCTOOfficial',
};

type GeneratorTheme = 'moon' | 'capsule' | 'power' | 'wealth';

function useReveal() {
  useEffect(() => {
    const obs = new IntersectionObserver(
      entries => entries.forEach(entry => entry.isIntersecting && entry.target.classList.add('in')),
      { threshold: 0.15 }
    );
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (dot.current) dot.current.style.transform = `translate(${e.clientX - 6}px, ${e.clientY - 6}px)`;
      if (ring.current) ring.current.style.transform = `translate(${e.clientX - 20}px, ${e.clientY - 20}px)`;
    };
    window.addEventListener('mousemove', move);
    return () => window.removeEventListener('mousemove', move);
  }, []);

  return (
    <>
      <div ref={dot} className="cursor-dot hidden md:block" />
      <div ref={ring} className="cursor-ring hidden md:block" />
    </>
  );
}

function Backdrop() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      <div className="absolute inset-0 green-gradient" />
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="absolute inset-0 noise opacity-[0.05]" />
      {[...Array(10)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full blur-3xl animate-drift"
          style={{
            width: `${180 + i * 30}px`,
            height: `${180 + i * 30}px`,
            top: `${(i * 13) % 100}%`,
            left: `${(i * 21) % 100}%`,
            background: i % 2 === 0 ? 'rgba(184,255,0,0.08)' : 'rgba(74,222,128,0.07)',
            animationDuration: `${10 + i * 2}s`,
          }}
        />
      ))}
    </div>
  );
}

function StatusBar() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="border-b border-acid/10 bg-black/40 backdrop-blur-md text-[10px] md:text-xs font-mono uppercase tracking-widest">
      <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between text-acid/70">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-acid animate-pulse" style={{ background: '#b8ff00' }} />
          <span>pond://freg-cto-live</span>
        </div>
        <div className="hidden md:flex items-center gap-4">
          <span>solana</span>
          <span>community-owned</span>
          <span>meme-engine-online</span>
        </div>
        <div className="text-acid">{time.toLocaleTimeString('en-US', { hour12: false })} UTC</div>
      </div>
    </div>
  );
}

function Nav() {
  const [open, setOpen] = useState(false);
  const items = [
    ['Gallery', '#gallery'],
    ['Why FREG', '#why'],
    ['Generator', '#generator'],
    ['Roadmap', '#roadmap'],
    ['Community', '#community'],
  ];

  return (
    <nav className="sticky top-0 z-50 bg-black/55 backdrop-blur-xl border-b border-acid/10">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        <a href="#top" className="flex items-center gap-3">
          <img src={images.logo} alt="FREG logo" className="w-12 h-12 rounded-full object-cover border-2 border-acid/50 shadow-[0_0_30px_rgba(184,255,0,0.25)]" />
          <div>
            <div className="font-display text-2xl text-acid leading-none">$FREG</div>
            <div className="text-[10px] uppercase tracking-[0.35em] text-white/45">community takeover</div>
          </div>
        </a>

        <div className="hidden lg:flex items-center gap-7">
          {items.map(([label, href]) => (
            <a key={href} href={href} className="text-white/70 hover:text-acid transition text-sm">
              {label}
            </a>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <a href={links.twitter} target="_blank" rel="noreferrer" className="btn-ghost px-4 py-2 rounded-full text-sm">X Community</a>
          <a href={links.telegram} target="_blank" rel="noreferrer" className="btn-acid px-5 py-2.5 rounded-full text-sm">Join Telegram</a>
        </div>

        <button onClick={() => setOpen(!open)} className="lg:hidden text-acid">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
        </button>
      </div>
      {open && (
        <div className="lg:hidden px-4 pb-4 space-y-3 bg-black/95 border-t border-acid/10">
          {items.map(([label, href]) => (
            <a key={href} href={href} onClick={() => setOpen(false)} className="block text-white/80 hover:text-acid">{label}</a>
          ))}
          <a href={links.twitter} target="_blank" rel="noreferrer" className="block btn-ghost rounded-full px-4 py-2 text-center">X Community</a>
          <a href={links.telegram} target="_blank" rel="noreferrer" className="block btn-acid rounded-full px-4 py-2 text-center">Join Telegram</a>
        </div>
      )}
    </nav>
  );
}

function ContractStrip() {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    await navigator.clipboard.writeText(CA);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="glass-strong rounded-2xl p-2 md:p-3 flex flex-col md:flex-row items-stretch md:items-center gap-3">
      <div className="px-4 py-2 text-xs uppercase tracking-[0.3em] text-acid/80 font-mono whitespace-nowrap">Contract //</div>
      <div className="flex-1 px-4 py-2 font-mono text-xs md:text-sm text-white/90 break-all md:truncate">{CA}</div>
      <button onClick={copy} className="btn-acid px-5 py-3 rounded-xl text-xs md:text-sm uppercase tracking-wider whitespace-nowrap">{copied ? '✓ Copied' : 'Copy CA'}</button>
    </div>
  );
}

function Hero() {
  return (
    <section id="top" className="relative pt-10 pb-20 md:pt-20 md:pb-28 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-7 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs uppercase tracking-widest text-acid font-mono mb-6 reveal">
            <span className="w-1.5 h-1.5 rounded-full bg-acid animate-pulse" style={{ background: '#b8ff00' }} />
            Solana memecoin · community built · visual brand first
          </div>
          <h1 className="font-display text-[14vw] md:text-[8vw] lg:text-[7rem] leading-[0.85] mb-6 reveal">
            <span className="block acid-grad text-glow">FREG</span>
            <span className="block text-white/95 -mt-2">RULES THE POND</span>
            <span className="block text-acid/70 text-[7vw] md:text-[3vw] lg:text-[3rem] mt-3">A meme brand people remember.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/70 max-w-2xl mb-8 reveal">
            $FREG is built to be instantly recognizable: the capsule, the attitude, the art, the culture.
            A sticky meme identity designed to catch attention, grow community, and convert visitors into holders.
          </p>
          <div className="flex flex-wrap gap-3 reveal">
            <a href={links.jupiter} target="_blank" rel="noreferrer" className="btn-acid px-7 py-3.5 rounded-full text-base inline-flex items-center gap-2">Buy on Jupiter 🚀</a>
            <a href={links.telegram} target="_blank" rel="noreferrer" className="btn-ghost px-7 py-3.5 rounded-full text-base inline-flex items-center gap-2">Join Telegram</a>
            <a href={links.twitter} target="_blank" rel="noreferrer" className="btn-ghost px-7 py-3.5 rounded-full text-base inline-flex items-center gap-2">X Community</a>
          </div>
          <div className="mt-10 grid grid-cols-3 gap-3 max-w-xl reveal">
            {[
              ['4', 'Art styles'],
              ['100%', 'Community'],
              ['0%', 'Tax'],
            ].map(([v, l]) => (
              <div key={l} className="glass rounded-2xl px-4 py-3">
                <div className="font-display text-2xl md:text-3xl acid-grad">{v}</div>
                <div className="text-[10px] uppercase tracking-widest text-white/50">{l}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 relative flex justify-center items-center reveal">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-[500px] h-[500px] max-w-full rounded-full bg-acid/10 blur-3xl animate-pulse-glow" />
          </div>
          <div className="relative w-full max-w-[520px]">
            <div className="absolute -top-6 -left-4 rounded-full glass px-4 py-2 text-xs md:text-sm uppercase tracking-[0.25em] text-acid font-mono rotate-[-8deg]">FREG verified vibe</div>
            <div className="absolute -bottom-4 right-0 rounded-full bg-acid text-black font-display px-5 py-2 text-xl rotate-[9deg] shadow-2xl">CTO</div>
            <div className="relative rounded-[2rem] glass-strong p-4 md:p-6 overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(184,255,0,0.2),transparent_35%),radial-gradient(circle_at_80%_30%,rgba(74,222,128,0.15),transparent_30%)]" />
              <img src={images.logo} alt="FREG hero" className="relative z-10 w-full rounded-[1.5rem] object-cover shadow-[0_30px_80px_rgba(0,0,0,0.45)] animate-float-slow" />
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 mt-14 reveal">
        <ContractStrip />
      </div>
    </section>
  );
}

function Marquee({ reverse = false }: { reverse?: boolean }) {
  const items = ['FREG', '🐸', 'VISUAL MEME BRAND', '⚡', 'COMMUNITY TAKEOVER', '🌕', 'SOLANA', '🔥', 'POND ENERGY', '💚'];
  return (
    <div className="relative overflow-hidden border-y border-acid/15 bg-black/30 py-5">
      <div className={`marquee-track ${reverse ? 'animate-scroll-x-rev' : 'animate-scroll-x'}`}>
        {[...Array(2)].flatMap((_, j) => items.map((it, i) => (
          <span key={`${j}-${i}`} className="tape-item font-display text-2xl md:text-4xl text-acid">{it}</span>
        )))}
      </div>
    </div>
  );
}

function Gallery() {
  const cards = [
    { src: images.logo, title: 'Capsule FREG', text: 'The iconic origin image. Instantly recognizable and perfect for branding.' },
    { src: images.hand, title: 'Builder FREG', text: 'A stronger visual to signal confidence, community value, and growth energy.' },
    { src: images.rocket, title: 'Moon Mission FREG', text: 'Your high-momentum campaign image for raids, posts, and bullish storytelling.' },
    { src: images.power, title: 'Power Mode FREG', text: 'High-voltage art for hype banners, stickers, and launch graphics.' },
  ];

  return (
    <section id="gallery" className="py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-14 reveal">
          <div className="text-acid font-mono text-xs tracking-[0.4em] mb-3">VISUAL IDENTITY</div>
          <h2 className="font-display text-5xl md:text-7xl acid-grad mb-4">FREG GALLERY</h2>
          <p className="text-white/60 max-w-2xl mx-auto">A strong meme coin needs unforgettable art. This site now presents FREG like a real internet character, not just a ticker.</p>
        </div>
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
          {cards.map((card, index) => (
            <div key={card.title} className={`glass rounded-[1.75rem] overflow-hidden lift reveal ${index === 0 ? 'xl:translate-y-8' : ''}`}>
              <div className="aspect-square overflow-hidden">
                <img src={card.src} alt={card.title} className="w-full h-full object-cover hover:scale-105 transition duration-700" />
              </div>
              <div className="p-5">
                <h3 className="font-display text-2xl text-white mb-2">{card.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{card.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function WhyFreg() {
  const items = [
    ['Iconic character', 'FREG has a clean, repeatable mascot identity that stands out instantly in feeds and groups.'],
    ['Content machine', 'Multiple artwork angles mean endless memes, posters, edits, and campaign material.'],
    ['Easy to shill', 'The capsule frog concept is easy to explain, share, and remember.'],
    ['Community-first', 'This project lives through raids, memes, holders, and culture.'],
    ['High replay value', 'FREG can be remixed into any setting: moon, charts, luxury, gaming, anime, chaos.'],
    ['Investor magnetism', 'A polished front-end makes the project feel active, alive, and worth checking out.'],
  ];

  return (
    <section id="why" className="py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-14 reveal">
          <div className="text-acid font-mono text-xs tracking-[0.4em] mb-3">WHY FREG</div>
          <h2 className="font-display text-5xl md:text-7xl acid-grad mb-4">WHY NEW INVESTORS STOP & LOOK</h2>
          <p className="text-white/60 max-w-2xl mx-auto">This version of the website is designed to convert attention into curiosity — and curiosity into holders.</p>
        </div>
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
          {items.map(([title, text], i) => (
            <div key={title} className="glass rounded-3xl p-6 lift reveal">
              <div className="w-12 h-12 rounded-2xl mb-4 flex items-center justify-center bg-acid/10 border border-acid/25 text-acid font-display text-2xl">0{i + 1}</div>
              <h3 className="font-display text-2xl text-white mb-2">{title}</h3>
              <p className="text-white/60 text-sm leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function MemeGenerator() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [caption, setCaption] = useState('THE POND SENDS IT');
  const [subcaption, setSubcaption] = useState('$FREG CTO');
  const [theme, setTheme] = useState<GeneratorTheme>('moon');
  const [selectedImage, setSelectedImage] = useState(images.rocket);

  const themeStyles = useMemo(() => ({
    moon: {
      bg: ['#050816', '#110a2d'],
      accent: '#b8ff00',
      flare: '#8b5cf6',
    },
    capsule: {
      bg: ['#04110a', '#0f2612'],
      accent: '#b8ff00',
      flare: '#4ade80',
    },
    power: {
      bg: ['#0f0606', '#240707'],
      accent: '#b8ff00',
      flare: '#ff3b30',
    },
    wealth: {
      bg: ['#181408', '#30230b'],
      accent: '#f5ff7a',
      flare: '#f59e0b',
    },
  }), []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const style = themeStyles[theme];
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = selectedImage;

    img.onload = () => {
      canvas.width = 1080;
      canvas.height = 1350;

      const gradient = ctx.createLinearGradient(0, 0, 1080, 1350);
      gradient.addColorStop(0, style.bg[0]);
      gradient.addColorStop(1, style.bg[1]);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const glow = ctx.createRadialGradient(220, 250, 40, 220, 250, 520);
      glow.addColorStop(0, `${style.accent}55`);
      glow.addColorStop(1, 'transparent');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const flare = ctx.createRadialGradient(860, 190, 30, 860, 190, 300);
      flare.addColorStop(0, `${style.flare}66`);
      flare.addColorStop(1, 'transparent');
      ctx.fillStyle = flare;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = 'rgba(184,255,0,0.08)';
      ctx.lineWidth = 1;
      for (let i = 0; i < 24; i++) {
        ctx.beginPath();
        ctx.moveTo(0, i * 60);
        ctx.lineTo(canvas.width, i * 60);
        ctx.stroke();
      }

      const imageBox = { x: 90, y: 180, w: 900, h: 760 };
      ctx.save();
      ctx.beginPath();
      const r = 42;
      ctx.moveTo(imageBox.x + r, imageBox.y);
      ctx.lineTo(imageBox.x + imageBox.w - r, imageBox.y);
      ctx.quadraticCurveTo(imageBox.x + imageBox.w, imageBox.y, imageBox.x + imageBox.w, imageBox.y + r);
      ctx.lineTo(imageBox.x + imageBox.w, imageBox.y + imageBox.h - r);
      ctx.quadraticCurveTo(imageBox.x + imageBox.w, imageBox.y + imageBox.h, imageBox.x + imageBox.w - r, imageBox.y + imageBox.h);
      ctx.lineTo(imageBox.x + r, imageBox.y + imageBox.h);
      ctx.quadraticCurveTo(imageBox.x, imageBox.y + imageBox.h, imageBox.x, imageBox.y + imageBox.h - r);
      ctx.lineTo(imageBox.x, imageBox.y + r);
      ctx.quadraticCurveTo(imageBox.x, imageBox.y, imageBox.x + r, imageBox.y);
      ctx.closePath();
      ctx.clip();

      const scale = Math.max(imageBox.w / img.width, imageBox.h / img.height);
      const drawW = img.width * scale;
      const drawH = img.height * scale;
      const drawX = imageBox.x + (imageBox.w - drawW) / 2;
      const drawY = imageBox.y + (imageBox.h - drawH) / 2;
      ctx.drawImage(img, drawX, drawY, drawW, drawH);
      ctx.restore();

      ctx.fillStyle = 'rgba(0,0,0,0.34)';
      ctx.fillRect(90, 760, 900, 180);

      ctx.fillStyle = style.accent;
      ctx.font = '900 116px Arial';
      ctx.textAlign = 'left';
      ctx.shadowColor = `${style.accent}88`;
      ctx.shadowBlur = 30;
      ctx.fillText('FREG', 90, 118);
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#f3ffe5';
      ctx.font = '900 78px Arial';
      wrapText(ctx, caption.toUpperCase(), 90, 1035, 900, 86);

      ctx.fillStyle = `${style.accent}`;
      ctx.font = '600 42px Arial';
      wrapText(ctx, subcaption.toUpperCase(), 95, 1190, 890, 52);

      ctx.fillStyle = '#c8ff9a';
      ctx.font = '600 30px Arial';
      ctx.fillText(CA, 95, 1290);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#e8ffd8';
      ctx.fillText('fregcto.site', 980, 1290);
    };
  }, [caption, subcaption, selectedImage, theme, themeStyles]);

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `freg-generator-${theme}.png`;
    a.click();
  };

  const artOptions = [
    { label: 'Capsule', src: images.logo },
    { label: 'Builder', src: images.hand },
    { label: 'Rocket', src: images.rocket },
    { label: 'Power', src: images.power },
  ];

  return (
    <section id="generator" className="py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-14 reveal">
          <div className="text-acid font-mono text-xs tracking-[0.4em] mb-3">FREG MEME LAB</div>
          <h2 className="font-display text-5xl md:text-7xl acid-grad mb-4">GENERATE FREG IMAGES</h2>
          <p className="text-white/60 max-w-2xl mx-auto">Create downloadable FREG raid posters directly on the website. Pick the art, set the vibe, write the message, and post it everywhere.</p>
        </div>

        <div className="grid xl:grid-cols-[1fr_520px] gap-8 items-start">
          <div className="glass rounded-[2rem] p-6 md:p-8 reveal">
            <div className="grid md:grid-cols-2 gap-5">
              <div>
                <label className="block text-sm text-white/70 mb-2">Main headline</label>
                <input value={caption} onChange={e => setCaption(e.target.value)} className="w-full rounded-2xl bg-black/40 border border-acid/20 px-4 py-3 text-white outline-none focus:border-acid" placeholder="THE POND SENDS IT" />
              </div>
              <div>
                <label className="block text-sm text-white/70 mb-2">Subheadline</label>
                <input value={subcaption} onChange={e => setSubcaption(e.target.value)} className="w-full rounded-2xl bg-black/40 border border-acid/20 px-4 py-3 text-white outline-none focus:border-acid" placeholder="$FREG CTO" />
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm text-white/70 mb-3">Theme</label>
              <div className="grid sm:grid-cols-4 gap-3">
                {(['moon', 'capsule', 'power', 'wealth'] as GeneratorTheme[]).map(option => (
                  <button key={option} onClick={() => setTheme(option)} className={`rounded-2xl px-4 py-3 border text-sm uppercase tracking-widest ${theme === option ? 'bg-acid text-black border-acid' : 'bg-black/30 text-white/70 border-acid/20 hover:border-acid/50'}`}>
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm text-white/70 mb-3">Choose artwork</label>
              <div className="grid sm:grid-cols-4 gap-3">
                {artOptions.map(option => (
                  <button key={option.label} onClick={() => setSelectedImage(option.src)} className={`rounded-[1.25rem] overflow-hidden border ${selectedImage === option.src ? 'border-acid shadow-[0_0_25px_rgba(184,255,0,0.3)]' : 'border-acid/15'}`}>
                    <img src={option.src} alt={option.label} className="aspect-square w-full object-cover" />
                    <div className="px-3 py-2 text-xs uppercase tracking-widest bg-black/60 text-white/80">{option.label}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={download} className="btn-acid px-6 py-3 rounded-full">Download PNG</button>
              <button onClick={() => { setCaption('THE POND SENDS IT'); setSubcaption('$FREG CTO'); setTheme('moon'); setSelectedImage(images.rocket); }} className="btn-ghost px-6 py-3 rounded-full">Reset</button>
            </div>
          </div>

          <div className="reveal sticky top-24">
            <div className="glass-strong rounded-[2rem] p-4 md:p-5">
              <canvas ref={canvasRef} className="w-full rounded-[1.5rem] bg-black/40 border border-acid/15" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Tokenomics() {
  const items = [
    ['1B', 'Total supply'],
    ['0%', 'Tax'],
    ['100%', 'Community'],
    ['SOL', 'Chain'],
  ];
  return (
    <section className="py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-14 reveal">
          <div className="text-acid font-mono text-xs tracking-[0.4em] mb-3">TOKENOMICS</div>
          <h2 className="font-display text-5xl md:text-7xl acid-grad mb-4">SIMPLE. MEMEABLE. CLEAN.</h2>
        </div>
        <div className="grid md:grid-cols-4 gap-5">
          {items.map(([value, label]) => (
            <div key={label} className="glass rounded-3xl p-6 text-center lift reveal">
              <div className="font-display text-5xl acid-grad mb-2">{value}</div>
              <div className="text-white/60 uppercase tracking-widest text-xs">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Roadmap() {
  const steps = [
    ['Pond Setup', 'Site, socials, identity, chart tools, and art assets go live.', 'LIVE'],
    ['Content Expansion', 'More memes, edits, reels, stickers, and daily community posting.', 'NOW'],
    ['Culture Push', 'Collabs, spaces, raids, and stronger ecosystem presence.', 'NEXT'],
    ['FREG Everywhere', 'Full meme saturation across the timeline, chats, and trader circles.', 'SOON'],
  ];
  return (
    <section id="roadmap" className="py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-14 reveal">
          <div className="text-acid font-mono text-xs tracking-[0.4em] mb-3">ROADMAP</div>
          <h2 className="font-display text-5xl md:text-7xl acid-grad mb-4">THE NEXT HOPS</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {steps.map(([title, text, badge], i) => (
            <div key={title} className="glass rounded-[1.75rem] p-6 reveal lift">
              <div className="flex items-center justify-between gap-4 mb-4">
                <div className="font-display text-3xl text-white">0{i + 1}. {title}</div>
                <div className="rounded-full px-3 py-1 text-xs uppercase tracking-widest bg-acid/10 text-acid border border-acid/30">{badge}</div>
              </div>
              <p className="text-white/60 leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Community() {
  return (
    <section id="community" className="py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-4">
        <div className="glass-strong rounded-[2rem] p-8 md:p-12 relative overflow-hidden reveal">
          <div className="absolute right-0 bottom-0 w-60 h-60 bg-acid/10 blur-3xl rounded-full" />
          <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-10 items-center">
            <div>
              <div className="text-acid font-mono text-xs tracking-[0.4em] mb-3">JOIN THE POND</div>
              <h2 className="font-display text-5xl md:text-7xl acid-grad mb-4">BECOME A FREG HOLDER</h2>
              <p className="text-white/65 text-lg max-w-2xl mb-8">The strongest meme coins feel alive. That means active chat, recognizable art, and a website people actually remember. FREG now has all three.</p>
              <div className="flex flex-wrap gap-3">
                <a href={links.telegram} target="_blank" rel="noreferrer" className="btn-acid px-6 py-3 rounded-full">Telegram</a>
                <a href={links.twitter} target="_blank" rel="noreferrer" className="btn-ghost px-6 py-3 rounded-full">X Community</a>
                <a href={links.dex} target="_blank" rel="noreferrer" className="btn-ghost px-6 py-3 rounded-full">DexScreener</a>
                <a href={links.birdeye} target="_blank" rel="noreferrer" className="btn-ghost px-6 py-3 rounded-full">Birdeye</a>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[images.logo, images.hand, images.rocket, images.power].map((src, i) => (
                <img key={i} src={src} alt={`FREG art ${i + 1}`} className="rounded-[1.4rem] border border-acid/15 object-cover aspect-square lift" />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-acid/10 py-10">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6 text-sm text-white/45">
        <div className="flex items-center gap-3">
          <img src={images.logo} alt="FREG" className="w-10 h-10 rounded-full object-cover border border-acid/25" />
          <div>
            <div className="font-display text-acid text-2xl leading-none">$FREG</div>
            <div>Community-owned Solana memecoin.</div>
          </div>
        </div>
        <div className="flex items-center gap-4 flex-wrap justify-center">
          <a href={links.twitter} target="_blank" rel="noreferrer" className="hover:text-acid">X</a>
          <a href={links.telegram} target="_blank" rel="noreferrer" className="hover:text-acid">Telegram</a>
          <a href={links.dex} target="_blank" rel="noreferrer" className="hover:text-acid">DexScreener</a>
          <a href={links.pump} target="_blank" rel="noreferrer" className="hover:text-acid">Pump.fun</a>
        </div>
      </div>
    </footer>
  );
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
  const words = text.split(' ');
  let line = '';
  const lines: string[] = [];
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && n > 0) {
      lines.push(line);
      line = `${words[n]} `;
    } else {
      line = testLine;
    }
  }
  lines.push(line);
  lines.forEach((entry, i) => ctx.fillText(entry.trim(), x, y + i * lineHeight));
}

export default function App() {
  useReveal();

  return (
    <div className="min-h-screen text-white selection:bg-acid selection:text-black">
      <Cursor />
      <Backdrop />
      <StatusBar />
      <Nav />
      <Hero />
      <Marquee />
      <Gallery />
      <WhyFreg />
      <MemeGenerator />
      <Tokenomics />
      <Marquee reverse />
      <Roadmap />
      <Community />
      <Footer />
    </div>
  );
}
